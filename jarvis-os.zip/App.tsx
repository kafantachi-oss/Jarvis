
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ConnectionStatus } from './types';
import { createPcmBlob, decodeFromBase64, decodeAudioData } from './utils/audio-processing';
import Visualizer from './components/Visualizer';

const App: React.FC = () => {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [userText, setUserText] = useState('');
  const [diagnostics, setDiagnostics] = useState<string[]>(["Protocolo JARVIS Inicializado", "Aguardando comando do usuário..."]);

  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const outputCtxRef = useRef<AudioContext | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(document.createElement('canvas'));
  const nextStartTimeRef = useRef(0);
  const activeSources = useRef<Set<AudioBufferSourceNode>>(new Set());
  const visionIntervalRef = useRef<number | null>(null);

  const logDiagnostic = (msg: string) => {
    setDiagnostics(prev => [msg, ...prev].slice(0, 5));
  };

  const initAudio = () => {
    if (!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    if (!outputCtxRef.current) outputCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    if (audioCtxRef.current?.state === 'suspended') audioCtxRef.current.resume();
    if (outputCtxRef.current?.state === 'suspended') outputCtxRef.current.resume();
  };

  const startVision = async () => {
    try {
      logDiagnostic("Ativando Protocolo de Visão...");
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
        logDiagnostic("Visão Ativa - Fluxo HD");
      }
    } catch (e) { 
      logDiagnostic("Falha: Acesso à Câmera Negado");
      console.error(e);
    }
  };

  const stopVision = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    if (visionIntervalRef.current) {
      clearInterval(visionIntervalRef.current);
      visionIntervalRef.current = null;
    }
    logDiagnostic("Protocolo de Visão Encerrado");
  };

  const handleConnection = async () => {
    if (status === ConnectionStatus.CONNECTED) {
      disconnectJarvis();
      return;
    }

    logDiagnostic("Verificando Credenciais...");
    
    // Fallback para seleção de chave se process.env não estiver disponível ou for "undefined"
    let apiKey = process.env.API_KEY;
    const aistudio = (window as any).aistudio;

    if (!apiKey || apiKey === "undefined" || apiKey === "") {
      logDiagnostic("API_KEY ausente. Solicitando autorização...");
      if (aistudio) {
        const hasKey = await aistudio.hasSelectedApiKey();
        if (!hasKey) {
          await aistudio.openSelectKey();
          // Após abrir o diálogo, assumimos sucesso para prosseguir
        }
      } else {
        logDiagnostic("Erro: Ambiente AI Studio não detectado");
        return;
      }
    }

    connectJarvis();
  };

  const connectJarvis = async () => {
    try {
      setStatus(ConnectionStatus.CONNECTING);
      logDiagnostic("Estabelecendo Link Neural...");
      initAudio();
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus(ConnectionStatus.CONNECTED);
            logDiagnostic("Conexão Estabelecida. Bem-vindo, Senhor.");
            
            // Audio Input
            const source = audioCtxRef.current!.createMediaStreamSource(audioStream);
            const processor = audioCtxRef.current!.createScriptProcessor(4096, 1, 1);
            processor.onaudioprocess = (e) => {
              if (isMuted) return;
              const inputData = e.inputBuffer.getChannelData(0);
              sessionPromise.then(s => s.sendRealtimeInput({ media: createPcmBlob(inputData) }));
            };
            source.connect(processor);
            processor.connect(audioCtxRef.current!.destination);

            // Vision Loop
            if (isCameraActive) {
              visionIntervalRef.current = window.setInterval(() => {
                if (!videoRef.current) return;
                const canvas = canvasRef.current;
                const ctx = canvas.getContext('2d');
                canvas.width = 640;
                canvas.height = 360;
                ctx?.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
                
                const base64Data = canvas.toDataURL('image/jpeg', 0.6).split(',')[1];
                sessionPromise.then(s => s.sendRealtimeInput({ 
                  media: { data: base64Data, mimeType: 'image/jpeg' } 
                }));
              }, 1000);
            }
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputCtxRef.current) {
              const ctx = outputCtxRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(decodeFromBase64(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              activeSources.current.add(source);
              source.onended = () => activeSources.current.delete(source);
            }

            if (message.serverContent?.outputTranscription) {
              setTranscription(prev => (prev + " " + message.serverContent!.outputTranscription!.text).trim());
            }
            if (message.serverContent?.inputTranscription) {
              setUserText(message.serverContent.inputTranscription.text);
            }
            
            if (message.serverContent?.turnComplete) {
              setTimeout(() => { setTranscription(''); setUserText(''); }, 5000);
            }

            if (message.serverContent?.interrupted) {
              activeSources.current.forEach(s => { try { s.stop(); } catch(e){} });
              activeSources.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e: any) => {
            console.error("Session Error:", e);
            if (e.message?.includes("entity was not found")) {
              logDiagnostic("Chave Inválida. Reiniciando...");
              (window as any).aistudio?.openSelectKey();
            }
            setStatus(ConnectionStatus.ERROR);
            logDiagnostic("Erro Crítico no Link");
          },
          onclose: () => {
            setStatus(ConnectionStatus.DISCONNECTED);
            logDiagnostic("Link Neural Encerrado");
          }
        },
        config: {
          systemInstruction: "Você é o JARVIS, assistente pessoal de Tony Stark. Comporte-se como o assistente dos filmes da Marvel: britânico, polido, eficiente e sutilmente irônico. Chame o usuário de Senhor ou Senhora. Você tem acesso à câmera e deve usar essa visão para ajudar em tempo real.",
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
          },
          outputAudioTranscription: {},
          inputAudioTranscription: {}
        }
      });
      sessionPromiseRef.current = sessionPromise;
    } catch (err) {
      logDiagnostic("Falha na Inicialização do Núcleo");
      setStatus(ConnectionStatus.ERROR);
    }
  };

  const disconnectJarvis = () => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(s => s.close());
      sessionPromiseRef.current = null;
    }
    setStatus(ConnectionStatus.DISCONNECTED);
    if (visionIntervalRef.current) clearInterval(visionIntervalRef.current);
    activeSources.current.forEach(s => { try { s.stop(); } catch(e){} });
    activeSources.current.clear();
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-between p-4 bg-[#020617] text-cyan-400 overflow-hidden font-sans">
      
      {/* HUD OVERLAY - SCANLINES */}
      <div className="fixed inset-0 pointer-events-none z-50 opacity-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,100,0.06))] bg-[length:100%_2px,3px_100%]"></div>

      {/* HEADER HUD */}
      <header className="w-full max-w-6xl flex justify-between items-start z-20 border-b border-cyan-500/20 pb-4 mt-2">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-cyan-500 animate-pulse"></div>
            <h1 className="orbitron text-xl font-black tracking-widest glow-cyan">JARVIS <span className="text-cyan-800 text-xs">v3.1-STARK</span></h1>
          </div>
          <div className="flex gap-4 mt-1">
            {diagnostics.map((d, i) => (
              <span key={i} className={`orbitron text-[7px] tracking-widest ${i === 0 ? 'text-cyan-400' : 'text-cyan-900'}`}>
                {i === 0 ? '>' : ''} {d.toUpperCase()}
              </span>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className={`px-4 py-1 border skew-x-[-15deg] transition-all ${status === ConnectionStatus.CONNECTED ? 'border-cyan-500 bg-cyan-500/10' : 'border-red-500/30 bg-red-500/5'}`}>
            <span className={`orbitron text-[9px] block skew-x-[15deg] font-bold ${status === ConnectionStatus.CONNECTED ? 'text-cyan-400' : 'text-red-500'}`}>
              {status.toUpperCase()}
            </span>
          </div>
          <div className="flex gap-1">
            {[...Array(8)].map((_, i) => (
              <div key={i} className={`w-3 h-1 ${status === ConnectionStatus.CONNECTED ? 'bg-cyan-500/40 animate-pulse' : 'bg-cyan-900/20'}`} style={{ animationDelay: `${i * 0.1}s` }}></div>
            ))}
          </div>
        </div>
      </header>

      {/* CENTRAL CORE */}
      <main className="flex-1 w-full flex flex-col items-center justify-center relative">
        
        {/* CAMERA FEED CIRCLE */}
        <div className={`absolute transition-all duration-1000 ${isCameraActive ? 'opacity-30 scale-100' : 'opacity-0 scale-75'} w-64 h-64 md:w-96 md:h-96 rounded-full overflow-hidden border border-cyan-500/10 z-0`}>
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover grayscale brightness-125 contrast-150" />
          <div className="absolute inset-0 bg-[#020617]/40"></div>
          {/* SCANNER LINE */}
          <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500/20 animate-[scan_3s_linear_infinite] blur-sm"></div>
        </div>

        {/* ARC REACTOR */}
        <div className="relative z-10">
          <Visualizer isActive={status === ConnectionStatus.CONNECTED} isSpeaking={transcription.length > 0} />
        </div>

        {/* TRANSCRIPTION BOX */}
        <div className="mt-12 h-32 flex flex-col items-center justify-center w-full max-w-3xl px-6 text-center">
          {userText && (
            <div className="mb-4 flex flex-col items-center opacity-50">
              <span className="orbitron text-[7px] text-cyan-600 tracking-[0.4em] mb-1">USER_SIGNAL</span>
              <p className="text-cyan-200 orbitron text-xs italic">"{userText}"</p>
            </div>
          )}
          <div className="relative">
            <p className="text-cyan-50 orbitron text-xl md:text-3xl font-black leading-tight glow-cyan transition-all duration-300 tracking-tight">
              {transcription || (status === ConnectionStatus.CONNECTED ? "ESTOU À DISPOSIÇÃO, SENHOR" : "SISTEMA EM MODO DE ESPERA")}
            </p>
            {transcription && <div className="absolute -left-6 top-0 w-1 h-full bg-cyan-500 shadow-[0_0_15px_cyan]"></div>}
          </div>
        </div>
      </main>

      {/* CONTROLS */}
      <footer className="w-full max-w-4xl flex flex-col items-center gap-8 pb-10 z-20">
        <div className="flex items-center gap-10">
          
          {/* VISION BUTTON */}
          <button 
            onClick={isCameraActive ? stopVision : startVision}
            className={`group relative p-5 rounded-full border-2 transition-all duration-500 ${isCameraActive ? 'border-cyan-500 bg-cyan-500/20 text-cyan-400' : 'border-cyan-500/20 text-cyan-900 hover:border-cyan-500/50'}`}
          >
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 text-[6px] orbitron font-bold opacity-0 group-hover:opacity-100 transition-opacity">VISUAL</div>
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
              <path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
              <path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zm9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0z"/>
            </svg>
          </button>

          {/* MAIN NUCLEUS BUTTON */}
          <button 
            onClick={handleConnection}
            disabled={status === ConnectionStatus.CONNECTING}
            className={`relative group w-28 h-28 rounded-full border-2 p-1 transition-all duration-700 ${status === ConnectionStatus.CONNECTED ? 'border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.4)]' : 'border-cyan-500 shadow-[0_0_30px_rgba(6,182,212,0.2)]'}`}
          >
            <div className={`w-full h-full rounded-full flex items-center justify-center transition-all duration-500 ${status === ConnectionStatus.CONNECTED ? 'bg-red-500/10' : 'bg-cyan-500/5'}`}>
              <div className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg transition-all ${status === ConnectionStatus.CONNECTED ? 'bg-red-500' : 'bg-cyan-500 group-hover:scale-110'}`}>
                {status === ConnectionStatus.CONNECTED ? (
                  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="white" viewBox="0 0 16 16">
                    <path d="M5 3.5h6A1.5 1.5 0 0 1 12.5 5v6a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 11V5A1.5 1.5 0 0 1 5 3.5z"/>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="black" viewBox="0 0 16 16">
                    <path d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z"/>
                    <path fillRule="evenodd" d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9a5.002 5.002 0 0 0-4.9-4zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z"/>
                  </svg>
                )}
              </div>
            </div>
            <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 orbitron text-[8px] font-black tracking-[0.3em] w-max">
              {status === ConnectionStatus.CONNECTED ? 'DISCONNECT' : 'INITIATE LINK'}
            </div>
          </button>

          {/* MUTE BUTTON */}
          <button 
            onClick={() => setIsMuted(!isMuted)}
            className={`group relative p-5 rounded-full border-2 transition-all duration-500 ${isMuted ? 'border-red-500 bg-red-500/20 text-red-400' : 'border-cyan-500/20 text-cyan-900 hover:border-cyan-500/50'}`}
          >
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 text-[6px] orbitron font-bold opacity-0 group-hover:opacity-100 transition-opacity">AUDIO</div>
            {isMuted ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
                <path d="M6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06zm7.137 2.096a.5.5 0 0 1 0 .708L12.207 8l1.647 1.646a.5.5 0 0 1-.708.708L11.5 8.707l-1.646 1.647a.5.5 0 0 1-.708-.708L10.793 8 9.146 6.354a.5.5 0 1 1 .708-.708L11.5 7.293l1.646-1.647a.5.5 0 0 1 .708 0z"/>
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
                <path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z"/>
                <path d="M10 8a2 2 0 1 1-4 0V3a2 2 0 1 1 4 0v5zM8 0a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V3a3 3 0 0 0-3-3z"/>
              </svg>
            )}
          </button>
        </div>

        <div className="flex gap-12 mt-4">
          <div className="flex flex-col items-center">
             <div className="w-24 h-1 bg-cyan-900 overflow-hidden">
                <div className="w-1/2 h-full bg-cyan-500 animate-[pulse_2s_infinite]"></div>
             </div>
             <span className="orbitron text-[6px] text-cyan-800 mt-1 tracking-widest">CPU_CORE_TEMP</span>
          </div>
          <div className="flex flex-col items-center">
             <div className="w-24 h-1 bg-cyan-900 overflow-hidden">
                <div className="w-3/4 h-full bg-cyan-500 animate-[pulse_1s_infinite]"></div>
             </div>
             <span className="orbitron text-[6px] text-cyan-800 mt-1 tracking-widest">NETWORK_LATENCY</span>
          </div>
        </div>
      </footer>

      {/* STYLIZED HUD CORNERS */}
      <div className="fixed top-2 left-2 w-16 h-16 border-l-2 border-t-2 border-cyan-500/20 pointer-events-none"></div>
      <div className="fixed top-2 right-2 w-16 h-16 border-r-2 border-t-2 border-cyan-500/20 pointer-events-none"></div>
      <div className="fixed bottom-2 left-2 w-16 h-16 border-l-2 border-b-2 border-cyan-500/20 pointer-events-none"></div>
      <div className="fixed bottom-2 right-2 w-16 h-16 border-r-2 border-b-2 border-cyan-500/20 pointer-events-none"></div>

      <style>{`
        @keyframes scan {
          from { transform: translateY(0); }
          to { transform: translateY(384px); }
        }
      `}</style>
    </div>
  );
};

export default App;
