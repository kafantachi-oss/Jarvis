
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ConnectionStatus } from './types';
import { createPcmBlob, decodeFromBase64, decodeAudioData } from './utils/audio-processing';
import Visualizer from './components/Visualizer';

const App: React.FC = () => {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [userText, setUserText] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const outputCtxRef = useRef<AudioContext | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(document.createElement('canvas'));
  const nextStartTimeRef = useRef(0);
  const activeSources = useRef<Set<AudioBufferSourceNode>>(new Set());
  const visionIntervalRef = useRef<number | null>(null);

  const initAudioContexts = () => {
    try {
      if (!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      if (!outputCtxRef.current) outputCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      if (audioCtxRef.current?.state === 'suspended') audioCtxRef.current.resume();
      if (outputCtxRef.current?.state === 'suspended') outputCtxRef.current.resume();
    } catch (e) {
      console.error("Audio Context Init Failed", e);
      setErrorMsg("Falha na inicialização do hardware de áudio.");
    }
  };

  const startVision = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (e) { 
      console.error("Vision failure:", e);
      setErrorMsg("Acesso à câmera negado. Protocolo visual offline.");
    }
  };

  const stopVision = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    if (visionIntervalRef.current) {
      clearInterval(visionIntervalRef.current);
      visionIntervalRef.current = null;
    }
  };

  const connectJarvis = async () => {
    if (!process.env.API_KEY || process.env.API_KEY === "undefined") {
      const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
      if (!hasKey) {
        await (window as any).aistudio?.openSelectKey();
      }
    }

    try {
      setStatus(ConnectionStatus.CONNECTING);
      setErrorMsg(null);
      initAudioContexts();
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus(ConnectionStatus.CONNECTED);
            
            const source = audioCtxRef.current!.createMediaStreamSource(audioStream);
            const scriptProcessor = audioCtxRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              if (isMuted || status !== ConnectionStatus.CONNECTED) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              }).catch(() => {});
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioCtxRef.current!.destination);

            if (isCameraActive) {
              visionIntervalRef.current = window.setInterval(() => {
                if (!videoRef.current || status !== ConnectionStatus.CONNECTED) return;
                const canvas = canvasRef.current;
                const ctx = canvas.getContext('2d');
                canvas.width = 480;
                canvas.height = 270;
                ctx?.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
                
                const base64Data = canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
                sessionPromise.then(session => {
                  session.sendRealtimeInput({ 
                    media: { data: base64Data, mimeType: 'image/jpeg' } 
                  });
                }).catch(() => {});
              }, 1500);
            }
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputCtxRef.current) {
              const ctx = outputCtxRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const audioBuffer = await decodeAudioData(decodeFromBase64(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              activeSources.current.add(source);
              source.onended = () => activeSources.current.delete(source);
            }

            if (message.serverContent?.outputTranscription) {
              setTranscription(prev => prev + message.serverContent!.outputTranscription!.text);
            }
            if (message.serverContent?.inputTranscription) {
              setUserText(message.serverContent.inputTranscription.text);
            }
            
            if (message.serverContent?.turnComplete) {
              setTimeout(() => { 
                setTranscription(''); 
                setUserText(''); 
              }, 4000);
            }

            if (message.serverContent?.interrupted) {
              activeSources.current.forEach(s => { try { s.stop(); } catch(e){} });
              activeSources.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error("Session Error:", e);
            setStatus(ConnectionStatus.ERROR);
            setErrorMsg("Erro na conexão neural. Verifique os logs.");
          },
          onclose: () => {
            setStatus(ConnectionStatus.DISCONNECTED);
            if (visionIntervalRef.current) clearInterval(visionIntervalRef.current);
          }
        },
        config: {
          systemInstruction: "Você é o JARVIS. Protocolo: Real-Life Assistant. Comportamento: Sutilmente sarcástico, impecavelmente educado, eficiente. Identifique o usuário como 'Senhor' ou 'Senhora'. Você tem acesso à câmera e localização. Use o conhecimento que vê para ser proativo.",
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
          },
          outputAudioTranscription: {},
          inputAudioTranscription: {}
        }
      });
      sessionPromiseRef.current = sessionPromise;
    } catch (err) {
      console.error("Critical Failure:", err);
      setStatus(ConnectionStatus.ERROR);
      setErrorMsg("Protocolo de inicialização falhou.");
    }
  };

  const disconnectJarvis = () => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => session.close()).catch(() => {});
      sessionPromiseRef.current = null;
    }
    setStatus(ConnectionStatus.DISCONNECTED);
    if (visionIntervalRef.current) clearInterval(visionIntervalRef.current);
    activeSources.current.forEach(s => { try { s.stop(); } catch(e){} });
    activeSources.current.clear();
    nextStartTimeRef.current = 0;
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-between p-4 md:p-8 bg-[#020617] text-cyan-400 overflow-hidden select-none">
      <div className="fixed inset-0 pointer-events-none z-50 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(2,6,23,0.4)_100%)]"></div>
      <div className="fixed inset-0 pointer-events-none z-50 opacity-[0.03] bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>

      <header className="w-full max-w-6xl flex justify-between items-end z-20 border-b border-cyan-500/20 pb-4">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-cyan-500 animate-pulse rounded-full shadow-[0_0_8px_cyan]"></div>
            <h1 className="orbitron text-xl md:text-2xl font-black tracking-tighter glow-cyan">JARVIS <span className="opacity-40">STARK_OS</span></h1>
          </div>
          <p className="text-[9px] orbitron text-cyan-700 tracking-[0.4em] uppercase mt-1">Uplink: Estável / Public_Build</p>
        </div>

        <div className={`px-4 py-2 rounded-sm border skew-x-[-12deg] transition-all duration-500 ${status === ConnectionStatus.CONNECTED ? 'border-cyan-500 bg-cyan-500/10' : 'border-red-500/50 bg-red-500/5'}`}>
          <span className={`orbitron text-[10px] block skew-x-[12deg] font-bold ${status === ConnectionStatus.CONNECTED ? 'text-cyan-400' : 'text-red-500 animate-pulse'}`}>
            {status === ConnectionStatus.CONNECTED ? 'LIVE_STREAM' : 'STANDBY_MODE'}
          </span>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center w-full relative z-10">
        <div className={`absolute top-1/2 -translate-y-1/2 transition-all duration-1000 ${isCameraActive ? 'opacity-30 scale-100' : 'opacity-0 scale-95 pointer-events-none'} w-64 h-64 md:w-96 md:h-96 rounded-full overflow-hidden border border-cyan-500/10`}>
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover grayscale brightness-110" />
        </div>

        <div className="relative group">
          <Visualizer 
            isActive={status === ConnectionStatus.CONNECTED} 
            isSpeaking={transcription.length > 0} 
          />
          {errorMsg && (
            <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 w-max px-4 py-1 bg-red-500/20 border border-red-500/50 rounded text-red-500 orbitron text-[10px] animate-pulse">
              SYSTEM_ERR: {errorMsg}
            </div>
          )}
        </div>

        <div className="mt-12 w-full max-w-2xl min-h-[100px] flex flex-col items-center justify-center px-6 text-center">
          <p className="text-cyan-50 px-4 py-2 orbitron text-lg md:text-2xl font-bold leading-relaxed glow-cyan h-24 overflow-hidden">
            {transcription || (status === ConnectionStatus.CONNECTED ? "SISTEMA ATIVO. AGUARDANDO COMANDO." : "PRESSIONE ENGAGE PARA INICIAR.")}
          </p>
        </div>
      </main>

      <footer className="w-full max-w-4xl flex flex-col items-center gap-8 pb-8 z-20">
        <div className="flex items-center gap-12">
          <button 
            onClick={isCameraActive ? stopVision : startVision}
            className={`p-4 rounded-full border transition-all ${isCameraActive ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300' : 'bg-slate-900/40 border-cyan-500/10 text-cyan-900'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16"><path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/><path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2zm.5 2a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zm9 2.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0z"/></svg>
          </button>

          <button 
            onClick={status === ConnectionStatus.CONNECTED ? disconnectJarvis : connectJarvis}
            className={`w-24 h-24 rounded-full border-2 transition-all duration-500 flex items-center justify-center ${status === ConnectionStatus.CONNECTED ? 'border-red-500 bg-red-500/10 shadow-[0_0_30px_rgba(239,68,68,0.4)]' : 'border-cyan-500 bg-cyan-500/10 hover:scale-105'}`}
          >
            <div className={`w-14 h-14 rounded-full transition-all ${status === ConnectionStatus.CONNECTED ? 'bg-red-600 animate-pulse' : 'bg-cyan-500 shadow-[0_0_15px_cyan]'}`}></div>
          </button>

          <button 
            onClick={() => setIsMuted(!isMuted)}
            className={`p-4 rounded-full border transition-all ${isMuted ? 'bg-red-500/20 border-red-500 text-red-400' : 'bg-slate-900/40 border-cyan-500/10 text-cyan-900'}`}
          >
            {isMuted ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16"><path d="M6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06zm7.137 2.096a.5.5 0 0 1 0 .708L12.207 8l1.647 1.646a.5.5 0 0 1-.708.708L11.5 8.707l-1.646 1.647a.5.5 0 0 1-.708-.708L10.793 8 9.146 6.354a.5.5 0 1 1 .708-.708L11.5 7.293l1.646-1.647a.5.5 0 0 1 .708 0z"/></svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16"><path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z"/><path d="M10 8a2 2 0 1 1-4 0V3a2 2 0 1 1 4 0v5zM8 0a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V3a3 3 0 0 0-3-3z"/></svg>
            )}
          </button>
        </div>
        <div className="orbitron text-[9px] opacity-20 tracking-widest">STARK INDUSTRIES / NEURAL_LINK_V4.0</div>
      </footer>
    </div>
  );
};

export default App;