
import React, { useEffect, useState } from 'react';

interface VisualizerProps {
  isActive: boolean;
  isSpeaking: boolean;
}

const Visualizer: React.FC<VisualizerProps> = ({ isActive, isSpeaking }) => {
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    let frame: number;
    const animate = () => {
      setRotation(prev => prev + (isActive ? (isSpeaking ? 2 : 0.8) : 0.2));
      frame = requestAnimationFrame(animate);
    };
    animate();
    return () => cancelAnimationFrame(frame);
  }, [isActive, isSpeaking]);

  const mainColor = isActive ? '#06b6d4' : '#ef4444';
  const glowOpacity = isSpeaking ? '0.8' : '0.4';

  return (
    <div className="relative flex items-center justify-center w-72 h-72 md:w-96 md:h-96">
      
      {/* Outer Support Rings */}
      <div 
        className="absolute inset-0 border border-cyan-500/10 rounded-full"
        style={{ transform: `rotate(${rotation * 0.5}deg)`, borderStyle: 'dotted' }}
      ></div>
      
      <div 
        className="absolute inset-6 border-2 border-cyan-500/5 rounded-full"
        style={{ transform: `rotate(-${rotation * 0.3}deg)`, borderDasharray: '40 20' }}
      ></div>

      {/* Main Rotating HUD Elements */}
      <div 
        className="absolute inset-10 border-t-2 border-b-2 border-cyan-500/20 rounded-full transition-all duration-500"
        style={{ transform: `rotate(${rotation}deg)` }}
      ></div>

      {/* reactive Hexagon Grid Background (SVG) */}
      <div className="absolute inset-16 opacity-10">
        <svg viewBox="0 0 100 100" className="w-full h-full fill-none stroke-cyan-500 stroke-[0.2]">
          <path d="M50 1L94 25V75L50 99L6 75V25L50 1Z" />
          <path d="M50 10L85 30V70L50 90L15 70V30L50 10Z" />
        </svg>
      </div>

      {/* Central Arc Reactor Core */}
      <div className={`relative z-10 w-40 h-40 md:w-48 md:h-48 rounded-full flex items-center justify-center transition-all duration-500 ${isSpeaking ? 'scale-110 shadow-[0_0_60px_rgba(6,182,212,0.4)]' : 'scale-100'}`}>
        
        {/* Core Glow Layer */}
        <div className={`absolute inset-0 rounded-full transition-all duration-700 ${isActive ? 'bg-cyan-500/20 blur-3xl' : 'bg-red-500/10 blur-xl'}`} style={{ opacity: glowOpacity }}></div>
        
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_15px_rgba(6,182,212,0.8)]">
          <defs>
            <radialGradient id="arcGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={mainColor} stopOpacity="0.9" />
              <stop offset="70%" stopColor={mainColor} stopOpacity="0.2" />
              <stop offset="100%" stopColor={mainColor} stopOpacity="0" />
            </radialGradient>
            
            <filter id="glow">
              <feGaussianBlur stdDeviation="1.5" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Background Core Circle */}
          <circle cx="50" cy="50" r="45" fill="none" stroke={mainColor} strokeWidth="0.5" opacity="0.2" />
          
          {/* Pulsing Core Center */}
          <circle 
            cx="50" cy="50" r={isSpeaking ? "28" : "24"} 
            fill="url(#arcGrad)" 
            className={`transition-all duration-300 ${isSpeaking ? 'animate-pulse' : ''}`}
          />

          {/* Technologic Ring Detail */}
          <g style={{ transformOrigin: 'center', transform: `rotate(${rotation * 2}deg)` }}>
            {[0, 60, 120, 180, 240, 300].map(angle => (
              <rect 
                key={angle}
                x="48" y="5" width="4" height="12" 
                fill={mainColor} 
                opacity="0.8"
                transform={`rotate(${angle} 50 50)`}
                rx="1"
              />
            ))}
          </g>

          {/* inner Data Circle */}
          <circle 
            cx="50" cy="50" r="35" 
            fill="none" 
            stroke={mainColor} 
            strokeWidth="1.5" 
            strokeDasharray="4 8"
            className="animate-[spin_20s_linear_infinite]"
          />

          {/* Center Eye / Aperture */}
          <circle cx="50" cy="50" r="12" fill="#020617" stroke={mainColor} strokeWidth="2" filter="url(#glow)" />
          <circle cx="50" cy="50" r="4" fill={mainColor} className={isSpeaking ? 'animate-ping' : ''} />
        </svg>

        {/* Floating Data Bits */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-2 left-1/2 -translate-x-1/2 orbitron text-[6px] text-cyan-500/60 font-bold">CORE_STABLE</div>
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 orbitron text-[6px] text-cyan-500/60 font-bold">SYNC_88.4%</div>
        </div>
      </div>

      {/* Digital HUD Frame Accents */}
      <div className="absolute top-0 right-0 orbitron text-[8px] text-cyan-500/40">SYS_UP: {(rotation/10).toFixed(1)}s</div>
      <div className="absolute bottom-0 left-0 orbitron text-[8px] text-cyan-500/40 tracking-widest">ENCRYPT_AES_256</div>
    </div>
  );
};

export default Visualizer;
