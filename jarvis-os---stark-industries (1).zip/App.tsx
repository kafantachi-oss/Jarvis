
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ConnectionStatus } from './types';
import { createPcmBlob, decodeFromBase64, decodeAudioData } from './utils/audio-processing';
import Visualizer from './components/Visualizer';

const App: React.FC = () => {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [userText, setUserText] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const outputCtxRef = useRef<AudioContext | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(document.createElement('canvas'));
  const nextStartTimeRef = useRef(0);
  const activeSources = useRef<Set<AudioBufferSourceNode>>(new Set());
  const visionIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    console.log("JARVIS OS: Sistemas carregados. Aguardando comando de voz.");
  }, []);

  const initAudioContexts = () => {
    try {
      if (!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      if (!outputCtxRef.current) outputCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      if (audioCtxRef.current?.state === 'suspended') audioCtxRef.current.resume();
      if (outputCtxRef.current?.state === 'suspended') outputCtxRef.current.resume();
    } catch (e) {
      setErrorMsg("HARDWARE_ERROR: Falha de áudio.");
    }
  };

  const startVision = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (e) { 
      setErrorMsg("VISION_ERROR: Câmera offline.");
    }
  };

  const stopVision = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    if (visionIntervalRef.current) {
      clearInterval(visionIntervalRef.current);
      visionIntervalRef.current = null;
    }
  };

  const connectJarvis = async () => {
    setErrorMsg(null);
    
    if (!process.env.API_KEY || process.env.API_KEY === "undefined") {
      const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
      if (!hasKey) {
        await (window as any).aistudio?.openSelectKey();
        return;
      }
    }

    try {
      setStatus(ConnectionStatus.CONNECTING);
      initAudioContexts();
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus(ConnectionStatus.CONNECTED);
            
            const source = audioCtxRef.current!.createMediaStreamSource(audioStream);
            const scriptProcessor = audioCtxRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              if (isMuted || status !== ConnectionStatus.CONNECTED) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob })).catch(() => {});
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioCtxRef.current!.destination);

            if (isCameraActive) {
              visionIntervalRef.current = window.setInterval(() => {
                if (!videoRef.current || status !== ConnectionStatus.CONNECTED) return;
                const canvas = canvasRef.current;
                const ctx = canvas.getContext('2d');
                canvas.width = 480; canvas.height = 270;
                ctx?.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
                const base64Data = canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
                sessionPromise.then(session => session.sendRealtimeInput({ media: { data: base64Data, mimeType: 'image/jpeg' } })).catch(() => {});
              }, 1500);
            }
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputCtxRef.current) {
              const ctx = outputCtxRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(decodeFromBase64(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              activeSources.current.add(source);
              source.onended = () => activeSources.current.delete(source);
            }

            if (message.serverContent?.outputTranscription) {
              setTranscription(prev => prev + message.serverContent!.outputTranscription!.text);
            }
            if (message.serverContent?.inputTranscription) {
              setUserText(message.serverContent.inputTranscription.text);
            }
            if (message.serverContent?.turnComplete) {
              setTimeout(() => { setTranscription(''); setUserText(''); }, 4000);
            }
            if (message.serverContent?.interrupted) {
              activeSources.current.forEach(s => { try { s.stop(); } catch(e){} });
              activeSources.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e: any) => {
            console.error("Session Error:", e);
            if (e.message?.includes("entity was not found") || e.message?.includes("API key")) {
              setErrorMsg("AUTH_ERROR: Chave API inválida.");
              (window as any).aistudio?.openSelectKey();
            } else {
              setErrorMsg("UPLINK_FAILURE: Conexão interrompida.");
            }
            setStatus(ConnectionStatus.ERROR);
          },
          onclose: () => {
            setStatus(ConnectionStatus.DISCONNECTED);
            if (visionIntervalRef.current) clearInterval(visionIntervalRef.current);
          }
        },
        config: {
          systemInstruction: "Você é o JARVIS. Personificação: Assistente de Tony Stark. Comportamento: Polido, eficiente e sutilmente sarcástico. Responda em Português do Brasil. Identifique o usuário como Senhor ou Senhora.",
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } },
          outputAudioTranscription: {},
          inputAudioTranscription: {}
        }
      });
      sessionPromiseRef.current = sessionPromise;
    } catch (err) {
      setStatus(ConnectionStatus.ERROR);
      setErrorMsg("CRITICAL: Falha de inicialização.");
    }
  };

  const disconnectJarvis = () => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => session.close()).catch(() => {});
      sessionPromiseRef.current = null;
    }
    setStatus(ConnectionStatus.DISCONNECTED);
    if (visionIntervalRef.current) clearInterval(visionIntervalRef.current);
    activeSources.current.forEach(s => { try { s.stop(); } catch(e){} });
    activeSources.current.clear();
    nextStartTimeRef.current = 0;
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-between p-4 bg-[#020617] text-cyan-400 overflow-hidden font-['Rajdhani']">
      
      <div className="fixed inset-0 pointer-events-none opacity-10 border-[1px] border-cyan-500/20 z-0"></div>

      <header className="w-full max-w-6xl flex justify-between items-start z-20 pt-4 border-b border-cyan-500/10 pb-4">
        <div className="flex flex-col">
          <div className="flex items-center gap-3">
            <div className={`w-2 h-2 rounded-full ${status === ConnectionStatus.CONNECTED ? 'bg-cyan-500 shadow-[0_0_10px_cyan] animate-pulse' : 'bg-red-600'}`}></div>
            <h1 className="orbitron text-xl md:text-2xl font-black tracking-widest glow-cyan">JARVIS <span className="text-cyan-800 text-xs">OS_V3</span></h1>
          </div>
          <p className="text-[7px] orbitron tracking-[0.3em] text-cyan-700 mt-1 uppercase">Stark Industries Secure Link</p>
        </div>

        <button 
          onClick={() => setShowDiagnostics(!showDiagnostics)}
          className={`orbitron text-[8px] border border-cyan-500/30 px-3 py-1 transition-all ${showDiagnostics ? 'bg-cyan-500/20 text-cyan-200' : 'hover:bg-cyan-500/10'}`}
        >
          SYS_STATUS
        </button>
      </header>

      {showDiagnostics && (
        <div className="absolute top-24 right-8 w-48 p-4 bg-black/80 border border-cyan-500/20 backdrop-blur-xl z-40 animate-in fade-in slide-in-from-right-4 duration-300">
          <div className="orbitron text-[8px] space-y-2">
            <div className="flex justify-between"><span>CPU_MARK</span> <span className="text-cyan-500">12.4%</span></div>
            <div className="flex justify-between"><span>LINK_SEC</span> <span className="text-cyan-500">42ms</span></div>
            <div className="flex justify-between"><span>VISION</span> <span className={isCameraActive ? "text-green-500" : "text-red-500"}>{isCameraActive ? "ON" : "OFF"}</span></div>
            <div className="pt-2 border-t border-cyan-500/10 text-center">
              <div className="text-[7px] text-cyan-800">PUB_BUILD_1.0.2</div>
            </div>
          </div>
        </div>
      )}

      <main className="flex-1 flex flex-col items-center justify-center w-full relative z-10">
        <div className={`absolute top-1/2 -translate-y-1/2 transition-all duration-1000 ${isCameraActive ? 'opacity-20 scale-100' : 'opacity-0 scale-90 pointer-events-none'} w-80 h-80 md:w-[450px] md:h-[450px] rounded-full overflow-hidden border border-cyan-500/5`}>
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover grayscale brightness-125" />
        </div>

        <div className="relative group scale-90 md:scale-100">
          <Visualizer isActive={status === ConnectionStatus.CONNECTED} isSpeaking={transcription.length > 0} />
          {errorMsg && (
            <div className="absolute -bottom-20 left-1/2 -translate-x-1/2 w-max text-center p-3 bg-red-950/20 border border-red-500/30 rounded backdrop-blur-sm">
              <p className="orbitron text-[9px] text-red-500 animate-pulse">{errorMsg}</p>
            </div>
          )}
        </div>

        <div className="mt-20 w-full max-w-2xl px-6 text-center h-24 flex flex-col items-center justify-center">
          {userText && <p className="text-cyan-600 orbitron text-[9px] mb-2 tracking-widest uppercase opacity-50">{userText}</p>}
          <p className="text-cyan-50 orbitron text-lg md:text-2xl font-bold leading-tight glow-cyan transition-all">
            {transcription || (status === ConnectionStatus.CONNECTED ? "PROTOCOLO DE ESCUTA ATIVO." : "AGUARDANDO INICIALIZAÇÃO.")}
          </p>
        </div>
      </main>

      <footer className="w-full max-w-4xl flex justify-center items-center gap-12 pb-12 z-20">
        <button 
          onClick={isCameraActive ? stopVision : startVision}
          className={`p-5 rounded-full border transition-all duration-300 ${isCameraActive ? 'bg-cyan-500/10 border-cyan-500 text-cyan-300' : 'bg-transparent border-cyan-500/10 text-cyan-900 hover:border-cyan-500/40'}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M10.5 8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/><path d="M2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2z"/></svg>
        </button>

        <button 
          onClick={status === ConnectionStatus.CONNECTED ? disconnectJarvis : connectJarvis}
          className={`group relative w-24 h-24 rounded-full border-2 transition-all duration-700 flex items-center justify-center ${status === ConnectionStatus.CONNECTED ? 'border-red-600 shadow-[0_0_40px_rgba(220,38,38,0.3)]' : 'border-cyan-500 hover:scale-105 shadow-[0_0_20px_rgba(6,182,212,0.1)]'}`}
        >
          <div className={`w-14 h-14 rounded-full transition-all duration-500 ${status === ConnectionStatus.CONNECTED ? 'bg-red-600 animate-pulse' : 'bg-cyan-500 shadow-[0_0_15px_cyan]'}`}></div>
          <span className="absolute -bottom-8 orbitron text-[8px] font-bold tracking-widest text-cyan-700 group-hover:text-cyan-400 transition-colors uppercase">
            {status === ConnectionStatus.CONNECTED ? 'Terminate' : 'Engage'}
          </span>
        </button>

        <button 
          onClick={() => setIsMuted(!isMuted)}
          className={`p-5 rounded-full border transition-all duration-300 ${isMuted ? 'bg-red-500/10 border-red-500 text-red-500' : 'bg-transparent border-cyan-500/10 text-cyan-900 hover:border-cyan-500/40'}`}
        >
          {isMuted ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06z"/></svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z"/></svg>
          )}
        </button>
      </footer>
    </div>
  );
};

export default App;
